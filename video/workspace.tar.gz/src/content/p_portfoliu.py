"""/portfoliu.html — работы бюро: реализованные проекты и концепты."""
from components import cta_block, page_head, phones, proof_bar
from config import CFG

CASES = {
    "/portfoliu/aura-dent.html": {
        "name": "Стоматология «Аура-Дент»", "kind": "Концепт", "niche": "Медицина",
        "district": "Московский район",
        "text": "Сайт 2016 года на Joomla 1.5: не открывался с телефона, форма не отправлялась, "
                "в коде — чужой скрипт-редирект на рекламную сеть.",
        "was": ("29", "7,4 с", "5,1 МБ", "17"), "now": ("99", "0,6 с", "268 КБ", "#3d7a8c"),
        "nums": [("PageSpeed", "29 → 99", True), ("Загрузка", "7,4 → 0,6 с", True),
                 ("Плагинов", "17 → 0", True)],
        "seed": 5,
    },
    "/portfoliu/severny-granit.html": {
        "name": "«Северный гранит»", "kind": "Реализовано", "niche": "Производство",
        "district": "Санкт-Петербург",
        "text": "Каталог изделий и прайс на 40 страниц. Перенесли весь контент, сохранили URL "
                "и позиции по 120 запросам, подключили формы в Telegram.",
        "was": ("41", "5,2 с", "3,6 МБ", "9"), "now": ("98", "0,8 с", "294 КБ", "#5c6b7a"),
        "nums": [("PageSpeed", "41 → 98", True), ("Заявок", "+38%", True),
                 ("Поддержка", "8 000 → 0 ₽", True)],
        "seed": 8,
    },
    "/portfoliu/avtomir-pulkovo.html": {
        "name": "Автосервис «АвтоМир Пулково»", "kind": "Концепт", "niche": "Автосервис",
        "district": "Пулковское шоссе",
        "text": "Сайт на конструкторе 2013 года, взломан дважды за год. Демо с онлайн-записью, "
                "подбором услуги и формой обратной связи.",
        "was": ("22", "9,1 с", "7,8 МБ", "31"), "now": ("97", "0,9 с", "352 КБ", "#8c5a2f"),
        "nums": [("PageSpeed", "22 → 97", True), ("Загрузка", "9,1 → 0,9 с", True),
                 ("Вес", "7,8 МБ → 352 КБ", True)],
        "seed": 11,
    },
}

DISCLAIM = """<div class="disclaim">
<b>О концептах.</b> Карточки с меткой «Концепт» — учебные работы бюро, подготовленные по открытым
материалам сайтов компаний. Эти компании не являются нашими клиентами и не участвовали в работе.
Названия изменены. Все права на тексты, логотипы и изображения принадлежат их владельцам;
материалы будут удалены по первому требованию — напишите на {email}.
</div>""".format(email=CFG["email"])


def card(url, c):
    tag_cls = "tag--ok" if c["kind"] == "Реализовано" else "tag--idea"
    nums = "".join(
        '<div>%s<b%s>%s</b></div>' % (n, ' class="g"' if g else "", v.replace(" → ", "<br>→ "))
        for n, v, g in c["nums"]
    )
    return f"""<a class="work" href="{url}">
  <div class="work__img">{phones(seed=c['seed'], was=c['was'], now=c['now'], cap=False)}</div>
  <div class="work__body">
    <div class="work__meta" style="margin:0 0 10px">
      <span class="tag {tag_cls}">{c['kind']}</span><span class="tag tag--ok">{c['niche']}</span></div>
    <h3>{c['name']}</h3>
    <p>{c['text']}</p>
    <div class="work__nums">{nums}</div>
    <p class="tiny" style="margin:0">{c['district']}</p>
  </div>
</a>"""


BODY = f"""
{page_head("Портфолио",
    "Реализованные проекты и концепты бюро: сравнение «было — стало», цифры PageSpeed, "
    "сроки и стоимость. Мобильные версии, потому что именно с телефона заходит большинство "
    "ваших клиентов.",
    [("/", "Главная"), ("", "Портфолио")],
    f'<div style="margin-top:20px">{proof_bar()}</div>')}

<section>
  <div class="wrap">
    <div class="row row--between" style="margin-bottom:24px">
      <div><span class="cap">Работы</span><h2 style="margin:0">Три кейса, три разные задачи</h2></div>
      <div class="row">
        <span class="tag tag--ok">Реализовано</span><span class="tag tag--idea">Концепт</span>
      </div>
    </div>
    <div class="works">
      {''.join(card(u, c) for u, c in CASES.items())}
    </div>
    <div style="margin-top:26px">{DISCLAIM}</div>
  </div>
</section>

<section class="sec--alt">
  <div class="wrap">
    <span class="cap">Как читать кейсы</span>
    <h2>Что значат цифры</h2>
    <div class="g3" style="margin-top:22px">
      <div class="card"><h3>PageSpeed Insights</h3><p class="small">Оценка Google от 0 до 100
      для мобильной версии. До 50 — сайт считается медленным, и это напрямую влияет на позиции
      в поиске и на долю отказов.</p></div>
      <div class="card"><h3>Время полной загрузки</h3><p class="small">Сколько секунд посетитель
      ждёт, пока страница станет usable. После 3 секунд уходит до половины мобильных посетителей —
      это ваши недополученные заявки.</p></div>
      <div class="card"><h3>Вес страницы</h3><p class="small">Сколько мегабайт качает телефон.
      4–7 МБ — типичная картина сайта на CMS с неоптимизированными фото. Статика с WebP —
      250–400 КБ, то есть в 10–20 раз меньше.</p></div>
    </div>
    <div class="note note--i" style="margin-top:22px">
      <p style="margin-bottom:0">Мы публикуем только то, что можем подтвердить: скриншоты
      PageSpeed до и после, архив исходного сайта с датой. На аудите так же покажем цифры
      по вашему сайту — и вы сможете проверить их сами в
      <a href="{CFG['psi']}{CFG['domain'].replace('https://', '')}" rel="noopener" target="_blank">
      PageSpeed Insights</a>.</p>
    </div>
  </div>
</section>

{cta_block(title="Хотите увидеть свой сайт в этом списке?",
           text="Соберём демо двух страниц вашего сайта за один рабочий день — бесплатно. "
                "Если понравится, станет вашим сайтом. Если нет — останется у нас в портфолио "
                "с пометкой «концепт».",
           btn="Заказать демо", href="/auditor.html")}
"""

PAGE = {
    "title": "Портфолио — пересборка сайтов в статические: кейсы и концепты | " + CFG["brand"],
    "description": "Кейсы бюро статики: сравнение «было — стало», PageSpeed, время загрузки "
                   "и вес страниц до и после пересборки. Реализованные проекты и концепты "
                   "для компаний Санкт-Петербурга.",
    "body": BODY, "active": "portfoliu", "path": "/portfoliu.html",
    "ld": {
        "@context": "https://schema.org", "@type": "ItemList", "name": "Портфолио бюро статики",
        "itemListElement": [
            {"@type": "ListItem", "position": i,
             "url": CFG["domain"] + u, "name": c["name"]}
            for i, (u, c) in enumerate(CASES.items(), 1)
        ],
    },
}
