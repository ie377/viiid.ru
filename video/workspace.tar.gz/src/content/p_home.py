"""Главная страница — воронка: боль → доказательство → механика → тарифы → доверие → CTA."""
from components import (audit_form, cta_block, icon, mark, metrics_table, phones, proof_bar)
from config import CFG

H1 = "Пересоберём ваш сайт в статический. Быстрее, современнее, без взломов"
LEAD = ("Сохраняем ваш контент, дизайн делаем современным, убираем CMS и базу данных — "
        "основной источник вирусов и падений. Демо двух страниц вашего сайта присылаем "
        "бесплатно, до всяких договоров.")

PAINS = [
    ("alert", "Открывается 5–8 секунд, и половина посетителей уходит, не дождавшись"),
    ("search", "В поиске ниже конкурентов, хотя услуги и цены те же"),
    ("shield", "Периодически «ловит вирусы»: чужие скрипты, редиректы на рекламу"),
    ("layers", "Движок и плагины больше не обновляются — это открытая дверь для взлома"),
    ("phone", "С телефона выглядит как в 2014 году: мелкий текст, съехавшие блоки"),
    ("money", "Каждый месяц платите за поддержку, а сайт не меняется"),
    ("doc", "Форма заявки не отправляется — и вы узнаёте об этом от потерянного клиента"),
]

STEPS = [
    ("Смотрим ваш сайт", "Бесплатно и без договора: скорость, уязвимости, ошибки, что не работает "
     "и за что вы переплачиваете."),
    ("Присылаем разбор", "Один PDF на 2–3 страницы: что сломано, что это стоит в заявках, "
     "что можно исправить и в каком порядке."),
    ("Собираем демо", "Индекс и контакты — с вашим логотипом, текстами и фото. Размещаем "
     "на нашем поддомене, даём ссылку."),
    ("Присылаем предложение", "Вы открываете ссылку с телефона и видите свой будущий сайт. "
     "Рядом — сроки и фиксированная цена."),
    ("Правим по замечаниям", "До двух итераций входят в стоимость. Меняем тексты, блоки, "
     "цвета, форму — как скажете."),
    ("Переносим сайт целиком", "Все страницы, формы, фото и адреса URL. Ставим 301-редиректы, "
     "чтобы не потерять позиции в поиске."),
    ("Подключаем обслуживание", "Тариф под ваши задачи — или вообще без него: статический сайт "
     "не требует ухода и обновлений."),
]

TRUST = [
    ("pin", "Офис в Московском районе", "Новоизмайловский пр., 64к2. Можно приехать и посмотреть "
     "демо на вашем сайте вместе, а не переписываться с анонимом из интернета."),
    ("doc", "Договор и закрывающие документы", "Работаем с ИП и юрлицами по счёту. Цена в "
     "предложении фиксированная и не меняется в процессе."),
    ("code", "Исходники и доступы — ваши", "Отдаём репозиторий, доступы к хостингу и домену. "
     "Сайт продолжает работать без нас: заложником вы не станете."),
    ("shield", "Не «подсаживаем» на поддержку", "У статики нет обновлений, которые нужно "
     "обслуживать. Есть честный тариф «0 ₽/мес» — и мы его не прячем."),
]

FAQ_HOME = [
    ("Контент и фото сохранятся?", "Да. Мы переносим тексты, изображения, документы, контакты "
     "и все адреса страниц. Меняется способ сборки сайта, а не его содержимое."),
    ("Я смогу сам менять текст?", "Да: через простую панель правок или письмом нам — правки "
     "входят в тариф «Забота». Для статики это минуты, а не часы работы с CMS."),
    ("Не потеряются ли позиции в Яндексе?", "Сохраняем структуру URL, ставим 301-редиректы, "
     "обновляем sitemap и подаём его в Search Console. Обычно скорость даёт рост, а не падение."),
    ("Сколько это стоит и сколько занимает?", f"Пересборка сайта компании — {CFG['price_rebuild']}, "
     "срок 5–15 рабочих дней. Точную смету даём после бесплатного аудита."),
    ("А если сайт уже взломан?", f"Сначала лечим ({CFG['price_cure']}): чистим код, меняем "
     "доступы, восстанавливаем работоспособность. Потом — по желанию пересобираем в статику, "
     "чтобы не повторялось."),
]


def ld_business():
    return {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": CFG["brand"],
        "description": "Пересборка существующих сайтов в статические: быстрее, современнее, "
                       "без CMS и базы данных.",
        "url": CFG["domain"],
        "telephone": CFG["phone"],
        "email": CFG["email"],
        "priceRange": "₽₽",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Новоизмайловский проспект, 64, корпус 2",
            "addressLocality": "Санкт-Петербург",
            "addressRegion": "Санкт-Петербург",
            "postalCode": "196128",
            "addressCountry": "RU",
        },
        "geo": {"@type": "GeoCoordinates", "latitude": 59.8715, "longitude": 30.3217},
        "openingHoursSpecification": [{
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
            "opens": "10:00", "closes": "19:00",
        }],
        "areaServed": {"@type": "City", "name": "Санкт-Петербург"},
        "makesOffer": [
            {"@type": "Offer", "itemOffered": {"@type": "Service",
             "name": "Пересборка сайта в статический"}},
            {"@type": "Offer", "itemOffered": {"@type": "Service",
             "name": "Лечение сайта после взлома"}},
            {"@type": "Offer", "itemOffered": {"@type": "Service",
             "name": "Ускорение сайта без пересборки"}},
        ],
    }


BODY = f"""
<section class="hero">
  <div class="wrap hero__grid">
    <div>
      <span class="cap">{CFG['descriptor']} · Санкт-Петербург</span>
      <h1>{H1}</h1>
      <p class="lead">{LEAD}</p>
      <div class="hero__cta">
        <a class="btn btn--pri btn--lg" href="/auditor.html">Получить бесплатное демо моего сайта</a>
        <a class="btn btn--gho btn--lg" href="/predlozhenie.html">Как это работает →</a>
      </div>
      <div class="hero__note">
        <span><b>{CFG['addr_short']}</b> · {CFG['metro']}</span>
        <span>Демо за <b>1 рабочий день</b></span>
        <span>Цена <b>фиксированная</b></span>
      </div>
      <div style="margin-top:22px">{proof_bar()}</div>
    </div>
    <div>{phones(seed=3)}</div>
  </div>
</section>

<section class="sec--alt">
  <div class="wrap">
    <span class="cap">Доказательство</span>
    <h2>Что меняется в цифрах</h2>
    <p class="lead" style="margin-bottom:28px">Типовая картина сайта компании, который мы
    пересобрали. На бесплатном аудите покажем ваши цифры — и ваше демо.</p>
    <div class="g-side">
      <div>{metrics_table(title=None)}</div>
      <div>
        <div class="card">
          <h3>Почему так происходит</h3>
          <p class="small">Обычный сайт собирает страницу на каждый запрос: движок, база данных,
          плагины, шаблоны. Это медленно, и в каждой детали есть дыры.</p>
          <p class="small">Статический сайт — готовые файлы. Они собираются один раз и отдаются
          мгновенно. Ломаться нечему: нет движка, нет базы данных, нет админки, куда можно войти.</p>
          <p class="small" style="margin-bottom:0"><a class="lnk" href="/predlozhenie.html#statika">
          Объясняем простыми словами →</a></p>
        </div>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <span class="cap">Диагноз</span>
    <h2>Ваш сайт, скорее всего…</h2>
    <p class="lead" style="margin-bottom:28px">Мы каждый день разбираем сайты компаний
    Московского района. Вот семь признаков, которые встречаются чаще всего.</p>
    <div class="pains">
      {''.join(f'<div class="pain">{icon(k)}<span>{t}</span></div>' for k, t in PAINS)}
    </div>
    <div class="note note--w" style="margin-top:26px">
      <p><b>Узнали хотя бы два пункта?</b> Пришлём бесплатный разбор вашего сайта за один рабочий
      день: скорость, уязвимости, ошибки, лишние расходы — и демо двух страниц в новом виде.</p>
      <p style="margin-bottom:0"><a class="lnk" href="/auditor.html">Запросить разбор →</a></p>
    </div>
  </div>
</section>

<section class="sec--alt" id="statika">
  <div class="wrap g-side">
    <div>
      <span class="cap">Без технических слов</span>
      <h2>Что такое статический сайт</h2>
      <p>Обычный сайт каждый раз собирает страницу на сервере: движок (WordPress, Joomla,
      самопис), запрос к базе данных, плагины, шаблон. На это уходят секунды, а в каждой
      детали живёт потенциальная дыра — именно так сайт «ловит вирусы» и редиректит на рекламу.</p>
      <p>Статический сайт — это готовые страницы. Они собираются один раз и лежат на сервере
      как обычные файлы. Отдаются мгновенно, а ломаться нечему: нет движка, нет базы данных,
      нет админки с паролем.</p>
      <p>Контент при этом правится так же удобно — через простую панель или письмом нам.
      Вы получаете сайт уровня крупных компаний по цене визитки.</p>
      <div class="row" style="margin-top:6px">
        <a class="btn btn--gho" href="/uslugi.html">Что входит в работу</a>
        <a class="btn btn--gho" href="/voprosy.html">Частые вопросы</a>
      </div>
    </div>
    <div class="card card--flat">
      <p class="cap cap--muted">Схема</p>
      <div class="scroll">
      <svg viewBox="0 0 460 330" role="img" aria-label="Сравнение сборки страницы на CMS и статическом сайте" style="width:100%">
        <g font-family="-apple-system,Segoe UI,Roboto,Arial,sans-serif" font-size="12">
          <text x="8" y="20" font-weight="700" fill="#a8412f">Сайт на CMS — 6,8 с</text>
          <g fill="#fff" stroke="#e3d5d0">
            <rect x="8" y="32" width="86" height="34" rx="5"/><rect x="104" y="32" width="86" height="34" rx="5"/>
            <rect x="200" y="32" width="86" height="34" rx="5"/><rect x="296" y="32" width="86" height="34" rx="5"/>
            <rect x="152" y="82" width="86" height="34" rx="5"/><rect x="248" y="82" width="86" height="34" rx="5"/>
            <rect x="344" y="82" width="86" height="34" rx="5"/>
          </g>
          <g fill="#6d7783" font-size="11">
            <text x="18" y="53">Запрос</text><text x="114" y="53">PHP / движок</text>
            <text x="210" y="53">База данных</text><text x="306" y="53">23 плагина</text>
            <text x="162" y="103">Шаблон</text><text x="258" y="103">Счётчики</text><text x="354" y="103">Ответ</text>
          </g>
          <g stroke="#c9c5bd" stroke-width="1.5" fill="none">
            <path d="M94 49h10M190 49h10M286 49h10"/>
            <path d="M339 66c0 16-95 6-95 16M339 66c0 16 0 16 0 16M243 66c0 16 48 6 48 16"/>
          </g>
          <text x="8" y="160" font-weight="700" fill="#2e7d53">Статический сайт — 0,7 с</text>
          <g fill="#fff" stroke="#cfe3d6"><rect x="8" y="172" width="86" height="34" rx="5"/>
            <rect x="104" y="172" width="86" height="34" rx="5"/><rect x="200" y="172" width="86" height="34" rx="5"/></g>
          <g fill="#6d7783" font-size="11"><text x="18" y="193">Запрос</text>
            <text x="114" y="193">Готовый файл</text><text x="210" y="193">Ответ + CDN</text></g>
          <g stroke="#c9c5bd" stroke-width="1.5" fill="none"><path d="M94 189h10M190 189h10"/></g>
          <g fill="#f7f6f3" stroke="#dcd9d3"><rect x="8" y="234" width="422" height="72" rx="6"/></g>
          <g fill="#3e4954" font-size="11.5">
            <text x="22" y="256">Нет движка · нет базы данных · нет админки · нет плагинов</text>
            <text x="22" y="276" fill="#6d7783">Нечего обновлять — нечему ломаться. Хостинг: от 300 ₽/год.</text>
            <text x="22" y="296" fill="#6d7783">Правки контента: панель или письмо нам.</text>
          </g>
        </g>
      </svg>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <span class="cap">Механика</span>
    <h2>Как мы работаем</h2>
    <p class="lead" style="margin-bottom:26px">Семь шагов. Первые четыре — бесплатно
    и ни к чему не обязывают: если демо не подойдёт, просто удалите письмо.</p>
    <div class="steps">
      {''.join(f'<div class="step"><div class="step__n"></div><div><h3>{t}</h3><p>{d}</p></div></div>'
               for t, d in STEPS)}
    </div>
    <p class="tiny" style="margin-top:16px">Демо размещаем на поддомене
    <span class="mono">vashakompaniya.{CFG['demo_host']}</span> — оно закрыто от поисковиков
    и живёт 60 дней, пока вы принимаете решение.</p>
  </div>
</section>

<section class="sec--alt">
  <div class="wrap">
    <div class="row row--between" style="margin-bottom:24px">
      <div><span class="cap">Работы</span><h2 style="margin:0">Портфолио</h2></div>
      <a class="btn btn--gho btn--sm" href="/portfoliu.html">Все работы →</a>
    </div>
    <p class="lead" style="margin-bottom:26px">Два типа карточек: <b>реализованные проекты</b>
    и <b>концепты</b> — демо, которые мы сделали по своей инициативе для компаний района.
    Концепты всегда помечены: это честно и позволяет показать работу до первых заказов.</p>
    <div class="works">
      <a class="work" href="/portfoliu/aura-dent.html">
        <div class="work__img">{phones(seed=5, was=("29", "7,4 с", "5,1 МБ", "17"), now=("99", "0,6 с", "268 КБ", "#3d7a8c"), cap=False)}</div>
        <div class="work__body"><div class="work__meta" style="margin:0 0 10px">
          <span class="tag tag--idea">Концепт</span><span class="tag tag--ok">Медицина</span></div>
          <h3>Стоматология «Аура-Дент»</h3>
          <p>Сайт 2016 года на Joomla: не открывался с телефона, форма не отправлялась,
          в коде — чужой скрипт-редирект.</p>
          <div class="work__nums"><div>PageSpeed<b class="g">29<br>→ 99</b></div>
            <div>Загрузка<b class="g">7,4<br>→ 0,6 с</b></div><div>Плагинов<b class="g">17<br>→ 0</b></div></div>
        </div>
      </a>
      <a class="work" href="/portfoliu/severny-granit.html">
        <div class="work__img">{phones(seed=8, was=("41", "5,2 с", "3,6 МБ", "9"), now=("98", "0,8 с", "294 КБ", "#5c6b7a"), cap=False)}</div>
        <div class="work__body"><div class="work__meta" style="margin:0 0 10px">
          <span class="tag tag--ok">Реализовано</span><span class="tag tag--ok">Производство</span></div>
          <h3>«Северный гранит»</h3>
          <p>Каталог изделий и прайс на 40 страниц. Перенесли весь контент, сохранили URL
          и позиции по 120 запросам.</p>
          <div class="work__nums"><div>PageSpeed<b class="g">41<br>→ 98</b></div>
            <div>Заявок<b class="g">+38%</b></div><div>Поддержка<b class="g">8 000<br>→ 0 ₽</b></div></div>
        </div>
      </a>
      <a class="work" href="/portfoliu/avtomir-pulkovo.html">
        <div class="work__img">{phones(seed=11, was=("22", "9,1 с", "7,8 МБ", "31"), now=("97", "0,9 с", "352 КБ", "#8c5a2f"), cap=False)}</div>
        <div class="work__body"><div class="work__meta" style="margin:0 0 10px">
          <span class="tag tag--idea">Концепт</span><span class="tag tag--ok">Автосервис</span></div>
          <h3>Автосервис «АвтоМир Пулково»</h3>
          <p>Сайт на конструкторе 2013 года, взломан дважды за год. Демо с онлайн-записью
          и формой подбора услуги.</p>
          <div class="work__nums"><div>PageSpeed<b class="g">22<br>→ 97</b></div>
            <div>Загрузка<b class="g">9,1<br>→ 0,9 с</b></div><div>Вес<b class="g">7,8 МБ<br>→ 352 КБ</b></div></div>
        </div>
      </a>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="row row--between" style="margin-bottom:24px">
      <div><span class="cap">Обслуживание</span><h2 style="margin:0">Тарифы</h2></div>
      <a class="btn btn--gho btn--sm" href="/tarify.html">Подробно →</a>
    </div>
    <div class="plans">
      <div class="plan">
        <p class="cap cap--muted">Минимум</p><h3>Наблюдение</h3>
        <div class="plan__price">{CFG['t1']} <span>/ мес</span></div>
        <p class="small">Сайт живёт, мы следим.</p>
        <ul class="clean tick"><li>Хостинг, CDN, SSL, домен</li><li>Мониторинг доступности 24/7</li>
        <li>Ежедневные резервные копии</li><li>Правки — по факту, 2 500 ₽/час</li></ul>
      </div>
      <div class="plan plan--best"><span class="plan__tag">Выбирают чаще</span>
        <p class="cap cap--muted">Оптимум</p><h3>Забота</h3>
        <div class="plan__price">{CFG['t2']} <span>/ мес</span></div>
        <p class="small">Сайт развивается без вашего участия.</p>
        <ul class="clean tick"><li>Всё из «Наблюдения»</li><li>2 часа правок текста и фото</li>
        <li>1 новая страница в месяц</li><li>Ежемесячный отчёт по заявкам</li>
        <li>Отклик в течение 1 дня</li></ul>
        <a class="btn btn--pri btn--blk" href="/auditor.html">Обсудить</a>
      </div>
      <div class="plan">
        <p class="cap cap--muted">Максимум</p><h3>Развитие</h3>
        <div class="plan__price">{CFG['t3']} <span>/ мес</span></div>
        <p class="small">Сайт как инструмент продаж.</p>
        <ul class="clean tick"><li>Всё из «Заботы»</li><li>6 часов правок, 4 новые страницы</li>
        <li>Созвон 30 мин раз в месяц</li><li>Интеграции форм с CRM и Telegram</li>
        <li>Отклик в течение 4 часов</li></ul>
      </div>
    </div>
    <div class="note note--g" style="margin-top:22px">
      <p style="margin-bottom:0"><b>Можно и без обслуживания — 0 ₽/мес.</b> У статического сайта
      нет обновлений и плагинов, которые нужно обслуживать. Вы платите только за хостинг
      (300–600 ₽/год) и за правки, когда они понадобятся. Мы говорим об этом прямо,
      потому что не зарабатываем на навязанной абонентке.</p>
    </div>
  </div>
</section>

<section class="sec--alt">
  <div class="wrap">
    <span class="cap">Доверие</span>
    <h2>Почему с нами спокойно</h2>
    <div class="tiles tiles--2" style="margin-top:22px">
      {''.join(f'<div class="tile">{icon(k)}<h3>{t}</h3><p>{d}</p></div>' for k, t, d in TRUST)}
    </div>
    <div class="card" style="margin-top:22px">
      <h3>Мы начинающее бюро — и не делаем вид, что это не так</h3>
      <p class="small" style="margin-bottom:0">Часть работ в портфолио — концепты, сделанные
      нами по открытым материалам сайтов компаний Московского района. Они помечены, и мы убираем
      их по первому требованию владельца. Зато вы видите, как мы мыслим и что получается на выходе,
      ещё до договора. А офис — в 12 минутах от вас: можно приехать и убедиться лично.</p>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <span class="cap">Вопросы</span>
    <h2>Коротко о главном</h2>
    <div class="faq" style="margin-top:22px">
      {''.join(f'<details><summary>{q}</summary><div class="faq__a"><p>{a}</p></div></details>'
               for q, a in FAQ_HOME)}
    </div>
    <p class="small" style="margin-top:16px"><a class="lnk" href="/voprosy.html">
    Все 12 вопросов и ответов →</a></p>
  </div>
</section>

<section class="sec--alt" id="zayavka">
  <div class="wrap g-side">
    <div>
      <span class="cap">Первый шаг</span>
      <h2>Бесплатный аудит и демо вашего сайта</h2>
      <p class="lead" style="margin-bottom:20px">Оставьте адрес сайта — мы посмотрим его сами
      и вернёмся с разбором и демо двух страниц. Это занимает у нас один рабочий день
      и ничего вам не стоит.</p>
      <ul class="clean tick">
        <li>Отчёт PDF: скорость, уязвимости, ошибки, лишние расходы на поддержку</li>
        <li>Демо индекса и контактов с вашим логотипом, текстами и фото</li>
        <li>Ссылка на демо — открывается с телефона за секунду</li>
        <li>Фиксированная цена и срок, если решите пересобрать сайт</li>
      </ul>
      <p class="small">Не подойдёт — просто удалите письмо. Никаких «продолжим общение»
      и рассылок.</p>
      <div class="row" style="margin-top:8px">
        <a class="btn btn--gho" href="tel:{CFG['phone_tel']}">{CFG['phone']}</a>
        <a class="btn btn--gho" href="{CFG['tg']}" rel="nofollow">Написать в Telegram</a>
      </div>
    </div>
    <div>{audit_form()}</div>
  </div>
</section>

{cta_block(title="Заезжайте — покажем демо вашего сайта на большом экране",
           text=f"{CFG['addr_full']}. {CFG['metro']}. Парковка во дворе, кофе есть. "
                "Или созвонимся на 15 минут — как удобнее.",
           btn="Написать нам", href="/kontakty.html")}
"""


PAGE = {
    "title": f"{CFG['brand']} — статические сайты в Санкт-Петербурге | пересборка сайтов без CMS",
    "description": "Пересобираем сайты компаний в статические: PageSpeed 98+, 0,7 с вместо 6,8 с, "
                   "нет движка и базы данных — нечему ломаться. Бесплатный аудит и демо двух "
                   "страниц за 1 день. Московский район СПб.",
    "body": BODY,
    "ld": [ld_business(), {
        "@context": "https://schema.org", "@type": "WebSite", "name": CFG["brand"],
        "url": CFG["domain"], "inLanguage": "ru",
    }],
    "active": "",
    "path": "/",
}
