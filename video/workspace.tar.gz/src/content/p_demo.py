"""/demo-obrazets.html — образец демо-страницы, которую получает клиент.

Это страница ВЫМЫШЛЕННОЙ компании «Аура-Дент»: так выглядит демо, которое бюро присылает
вместе с коммерческим предложением. В бою она лежит на {kompaniya}.demo.burostatiki.ru
с тем же бейджем и закрыта от поисковиков.
"""
from components import ICON, schema_map
from config import CFG

CLINIC = "Аура-Дент"

SERVICES = [
    ("Терапия", "Лечение кариеса, реставрация, лечение каналов под микроскопом.",
     [("Осмотр и консультация", "0 ₽"), ("Лечение кариеса", "от 3 900 ₽"),
      ("Лечение канала", "от 6 500 ₽"), ("Реставрация зуба", "от 5 200 ₽")]),
    ("Гигиена и отбеливание", "Профессиональная чистка, снятие камня, бережное отбеливание.",
     [("Ультразвуковая чистка", "3 200 ₽"), ("Air Flow", "2 800 ₽"),
      ("Комплекс гигиена + Air Flow", "4 900 ₽"), ("Отбеливание ZOOM", "18 000 ₽")]),
    ("Имплантация и протезирование", "Импланты, коронки, виниры, съёмное протезирование.",
     [("Имплант + работа", "от 42 000 ₽"), ("Коронка из диоксида циркония", "от 19 500 ₽"),
      ("Винир E-max", "от 27 000 ₽"), ("Протез съёмный", "от 24 000 ₽")]),
]

DOCS = [
    ("Елена Соколова", "Главный врач, терапевт · 16 лет практики"),
    ("Марат Гизатуллин", "Хирург-имплантолог · 11 лет практики"),
    ("Ольга Тихая", "Гигиенист, отбеливание · 9 лет практики"),
    ("Павел Рощин", "Ортопед, виниры и коронки · 13 лет практики"),
]

WHY = [
    ("clock", "Приём в день обращения", "Экстренная помощь — в течение двух часов после звонка, "
     "в том числе вечером и в субботу."),
    ("doc", "Смета до начала лечения", "План и стоимость фиксируем письменно. Никаких «дополнительно "
     "потребуется» в кресле."),
    ("shield", "Стерильность по СанПиН", "Одноразовые расходники, трёхступенчатая стерилизация "
     "с журналом, контроль каждой партии."),
    ("money", "Рассрочка без переплат", "На лечение от 30 000 ₽ — рассрочка на 6 месяцев "
     "без процентов и без банка-партнёра."),
]

svc_html = "".join(f"""
  <div class="card">
    <h3>{t}</h3><p class="small" style="min-height:44px">{d}</p>
    <div>{''.join(f'<div class="c-price"><span>{n}</span><b>{p}</b></div>' for n, p in rows)}</div>
  </div>""" for t, d, rows in SERVICES)

why_html = "".join(f'<div class="tile">{ICON[k]}<h3>{t}</h3><p>{d}</p></div>' for k, t, d in WHY)

docs_html = "".join(f"""
  <div><div class="c-doc__ph">фото врача</div>
    <p style="font-weight:600;margin:10px 0 2px;font-size:15px">{n}</p>
    <p class="tiny" style="margin:0">{r}</p></div>""" for n, r in DOCS)

BODY = f"""<div class="demo-bar">
  <b>Демо-концепт</b> бюро «Бюро статики» · учебная работа для вымышленной клиники «{CLINIC}» ·
  <a href="/" style="color:#dbe6f2;font-weight:600">burostatiki.ru</a>
</div>

<header class="hdr">
  <div class="wrap hdr__in">
    <div class="c-logo">
      <svg viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <rect width="32" height="32" rx="9" fill="#3d7a8c"/>
        <path d="M11 8c3 0 3 1.6 5 1.6S19 8 21 8c2.6 0 3.6 2.6 3 6-.5 3-1.6 10-3.6 10-1.7 0-1.6-6-4.4-6s-2.7 6-4.4 6C9.6 24 8.5 17 8 14c-.6-3.4.4-6 3-6z" fill="#fff"/></svg>
      {CLINIC}
    </div>
    <nav class="c-nav">
      <a href="#uslugi">Услуги и цены</a><a href="#vrachi">Врачи</a>
      <a href="#kontakty">Контакты</a>
    </nav>
    <a class="btn btn--pri btn--sm" href="#zapis" style="margin-left:auto;background:#3d7a8c">
      Записаться</a>
  </div>
</header>

<section class="c-hero">
  <div class="wrap hero__grid">
    <div>
      <span class="cap" style="color:#3d7a8c">Стоматология · Московский район</span>
      <h1>Лечим зубы спокойно: смета до начала, без очередей и «навязанных» услуг</h1>
      <p class="lead">Клиника «{CLINIC}» на Новоизмайловском проспекте. Приём в день обращения,
      план лечения и стоимость фиксируем письменно. Работаем с детьми и взрослыми,
      принимаем ДМС.</p>
      <div class="hero__cta">
        <a class="btn btn--lg" href="#zapis" style="background:#3d7a8c;color:#fff">
          Записаться на осмотр — 0 ₽</a>
        <a class="btn btn--gho btn--lg" href="tel:+78120000000">+7 (812) 000-00-00</a>
      </div>
      <div class="hero__note">
        <span><b>12 минут</b> от м. «Парк Победы»</span>
        <span>Пн–Сб <b>09:00–21:00</b></span>
        <span>Парковка <b>во дворе</b></span>
      </div>
    </div>
    <div class="card" style="border-color:#cfdde2">
      <h3 style="color:#2c5f6e">Ближайшее свободное время</h3>
      <div class="c-price"><span>Сегодня, 17:40</span><b>терапевт</b></div>
      <div class="c-price"><span>Сегодня, 19:20</span><b>гигиена</b></div>
      <div class="c-price"><span>Завтра, 10:00</span><b>хирург</b></div>
      <div class="c-price"><span>Завтра, 14:30</span><b>ортопед</b></div>
      <p class="tiny" style="margin:12px 0 0">Записываем по телефону и через форму — подтверждаем
      в течение 15 минут в рабочее время.</p>
    </div>
  </div>
</section>

<section id="uslugi">
  <div class="wrap">
    <span class="cap" style="color:#3d7a8c">Услуги и цены</span>
    <h2>Честный прайс, без звёздочек и «от» до бесконечности</h2>
    <p class="lead" style="margin-bottom:26px">Полный прайс на 4 страницах. Здесь — самое частое.
    Точную стоимость врач называет после осмотра и фиксирует в плане лечения.</p>
    <div class="c-svc">{svc_html}</div>
  </div>
</section>

<section class="sec--alt" id="vrachi">
  <div class="wrap">
    <span class="cap" style="color:#3d7a8c">Врачи</span>
    <h2>Кто вас принимает</h2>
    <div class="c-doc" style="margin-top:22px">{docs_html}</div>
  </div>
</section>

<section>
  <div class="wrap">
    <span class="cap" style="color:#3d7a8c">Почему к нам</span>
    <h2>Четыре вещи, которые важны пациенту</h2>
    <div class="tiles" style="margin-top:22px">{why_html}</div>
  </div>
</section>

<section class="sec--alt" id="zapis">
  <div class="wrap g-side">
    <div>
      <span class="cap" style="color:#3d7a8c">Запись</span>
      <h2>Запишитесь на бесплатный осмотр</h2>
      <p class="lead" style="margin-bottom:18px">Осмотр, консультация и план лечения с ценами —
      0 ₽. Если решите лечиться, стоимость осмотра вычитаем из счёта.</p>
      <ul class="clean tick">
        <li>Перезваниваем в течение 15 минут в рабочее время</li>
        <li>Подберём врача и время, напомним о приёме в мессенджер</li>
        <li>Принимаем ДМС: «СОГАЗ», «РЕСО», «АльфаСтрахование»</li>
      </ul>
    </div>
    <div class="form">
      <div class="field"><label for="d-name">Имя</label>
        <input id="d-name" type="text" placeholder="Как к вам обращаться" autocomplete="name"></div>
      <div class="field"><label for="d-tel">Телефон</label>
        <input id="d-tel" type="tel" placeholder="+7 (___) ___-__-__" autocomplete="tel"></div>
      <div class="field"><label for="d-svc">Услуга</label>
        <select id="d-svc"><option>Осмотр и консультация</option><option>Лечение кариеса</option>
        <option>Гигиена и отбеливание</option><option>Имплантация</option>
        <option>Протезирование, виниры</option><option>Детский приём</option></select></div>
      <label class="consent"><input type="checkbox" checked>
        <span>Согласен на обработку персональных данных</span></label>
      <button class="btn btn--blk" style="background:#3d7a8c;color:#fff">Записаться</button>
      <p class="tiny center" style="margin:10px 0 0">Или позвоните: +7 (812) 000-00-00</p>
    </div>
  </div>
</section>

<section id="kontakty">
  <div class="wrap">
    <span class="cap" style="color:#3d7a8c">Контакты</span>
    <h2>Как нас найти</h2>
    <div class="g-side" style="margin-top:22px">
      <div>{schema_map()}</div>
      <div class="card">
        <p class="small"><b>Адрес</b><br>Санкт-Петербург, Новоизмайловский проспект, д. 64, корпус 2</p>
        <p class="small"><b>Метро</b><br>«Парк Победы» — 12 минут пешком, «Московская» — 15 минут</p>
        <p class="small"><b>Часы работы</b><br>Пн–Пт 09:00–21:00, Сб 10:00–18:00, Вс — выходной</p>
        <p class="small"><b>Телефон</b><br>+7 (812) 000-00-00</p>
        <p class="small" style="margin-bottom:0"><b>Парковка</b><br>Во дворе клиники, места есть днём</p>
      </div>
    </div>
  </div>
</section>

<footer class="ftr">
  <div class="wrap">
    <div class="ftr__grid">
      <div><div class="ftr__brand">{CLINIC}</div>
        <p class="small" style="color:#98a2ae">Стоматология в Московском районе Санкт-Петербурга.
        Лицензия ЛО-77-01-000000 (демо).</p></div>
      <div><h4>Разделы</h4><ul>
        <li><a href="#uslugi">Услуги и цены</a></li><li><a href="#vrachi">Врачи</a></li>
        <li><a href="#zapis">Запись</a></li><li><a href="#kontakty">Контакты</a></li></ul></div>
      <div><h4>Пациентам</h4><ul>
        <li><a href="#zapis">Первый визит</a></li><li><a href="#uslugi">Рассрочка</a></li>
        <li><a href="#kontakty">ДМС</a></li><li><a href="#uslugi">Детский приём</a></li></ul></div>
      <div><h4>Контакты</h4><ul>
        <li>Новоизмайловский пр., 64к2</li><li>+7 (812) 000-00-00</li>
        <li>info@aura-dent.example</li><li class="tiny" style="color:#8d97a3">Пн–Сб 09:00–21:00</li></ul></div>
    </div>
    <div class="ftr__bottom">
      <span>© 2026 «{CLINIC}» · демо-концепт, вымышленная компания</span>
      <span class="ftr__built">Статика · 1 файл стилей · 0 плагинов</span>
    </div>
  </div>
</footer>

<div class="demo-badge">
  <b>Демо-концепт</b> бюро «Бюро статики» — учебная работа, компания вымышленная.
  Собрано за 1 день · статика, 0 плагинов · <a href="/">burostatiki.ru</a> · {CFG['phone']}
</div>
"""

PAGE = {
    "title": f"Демо-образец: сайт стоматологии «{CLINIC}» | {CFG['brand']}",
    "description": "Образец демо-страницы, которую бюро присылает вместе с коммерческим "
                   "предложением: главная и контакты, статическая сборка, вес страницы 30 КБ.",
    "body": BODY, "path": "/demo-obrazets.html", "noindex": True, "standalone": True,
    "body_class": "is-demo",
}
