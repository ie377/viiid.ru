"""/kontakty.html — контакты, карта, как добраться, реквизиты."""
from components import ICON, audit_form, page_head, proof_bar, schema_map
from config import CFG

BODY = f"""
{page_head("Контакты",
    f"{CFG['addr_full']}. {CFG['metro']}. Звоните, пишите в мессенджер или заезжайте — "
    "покажем демо вашего сайта на большом экране.",
    [("/", "Главная"), ("", "Контакты")])}

<section class="sec--tight">
  <div class="wrap g-side">
    <div>
      <div class="ct">
        <div class="ct__i">{ICON['pin']}<div><b>Адрес</b>
          {CFG['addr_full']}<br>
          <span class="small">{CFG['metro']}. Рядом Бассейная улица и Варшавская.</span></div></div>
        <div class="ct__i">{ICON['phone']}<div><b>Телефон</b>
          <a href="tel:{CFG['phone_tel']}">{CFG['phone']}</a><br>
          <span class="small">Звонки и SMS · WhatsApp по этому же номеру</span></div></div>
        <div class="ct__i">{ICON['mail']}<div><b>Почта</b>
          <a href="mailto:{CFG['email']}">{CFG['email']}</a><br>
          <span class="small">Для заявок, счетов и вопросов по договорам</span></div></div>
        <div class="ct__i">{ICON['chat']}<div><b>Мессенджеры</b>
          <a href="{CFG['tg']}" rel="nofollow">Telegram {CFG['tg_user']}</a><br>
          <span class="small">Отвечаем быстрее всего — обычно в течение часа в рабочее время</span></div></div>
        <div class="ct__i">{ICON['clock']}<div><b>Часы работы</b>
          {CFG['hours']}<br>
          <span class="small">Аудит и демо присылаем за один рабочий день, даже если заявка
          пришла в пятницу вечером</span></div></div>
        <div class="ct__i">{ICON['doc']}<div><b>Реквизиты</b>
          ООО «Бюро статики» · ИНН {CFG['inn']} · ОГРН {CFG['ogrn']}<br>
          <span class="small"><a href="/rekvizity.html">Полные реквизиты и договор-оферта →</a></span></div></div>
      </div>

      <div class="note note--i" style="margin-top:26px">
        <p style="margin-bottom:0"><b>Как добраться и где припарковаться.</b> Пешком от
        м. «Парк Победы» — 12 минут вдоль Новоизмайловского проспекта; от м. «Московская» —
        15 минут или две остановки наземным транспортом. На машине — съезд с Московского проспекта
        на Бассейную улицу, парковка во дворе и вдоль проспекта, днём места есть.
        Позвоните за час — встретим и проводим.</p>
      </div>

      <h2 style="margin-top:34px">Что происходит после обращения</h2>
      <ol class="clean">
        <li>Отвечаем в течение рабочего дня и уточняем пару деталей по сайту.</li>
        <li>В течение одного рабочего дня присылаем PDF-разбор и ссылку на демо двух страниц.</li>
        <li>Обсуждаем: созвон на 15 минут или встреча у нас в офисе — как удобнее.</li>
        <li>Если подходим друг другу — договор, фиксированная смета, работа. Если нет —
        отчёт остаётся у вас, мы не названиваем.</li>
      </ol>
    </div>

    <div>
      {audit_form(compact=True)}
      <p class="tiny" style="margin-top:14px">Форма отправляет письмо на {CFG['email']}
      и сообщение в Telegram. В реальной сборке — через serverless-функцию или сервис форм;
      тяжёлых скриптов на страницу это не добавляет.</p>
    </div>
  </div>
</section>

<section class="sec--alt">
  <div class="wrap">
    <span class="cap">На карте</span>
    <h2>Московский район, Новоизмайловский проспект</h2>
    <div style="margin-top:22px">{schema_map()}</div>
    <div class="note note--w" style="margin-top:20px">
      <p style="margin-bottom:0"><b>Про живую карту.</b> Интерактивный iframe Яндекс.Карт весит
      300–700 КБ и грузится в момент открытия страницы — это убивает скорость, за которую мы
      и продаём. Поэтому здесь статичная схема, а настоящая карта подключается ленивой загрузкой
      по клику «Открыть в Яндекс.Картах». Тот же принцип применяем и на сайтах клиентов.</p>
    </div>
  </div>
</section>

<section>
  <div class="wrap wrap-n">
    <div style="margin-bottom:20px">{proof_bar()}</div>
    <span class="cap">Проверьте нас</span>
    <h2>Сайт бюро собран так же, как мы предлагаем собрать ваш</h2>
    <ul class="clean tick">
      <li>Статическая сборка: ноль плагинов, ноль обновлений, ноль админки</li>
      <li>Один файл стилей на весь сайт, системные шрифты — никаких внешних загрузок</li>
      <li>Все иллюстрации — inline-SVG, фотографий-тяжеловесов нет</li>
      <li>Строгие заголовки безопасности: CSP, X-Frame-Options, Referrer-Policy</li>
      <li>Сжатие, кэш и страница 404 настроены на сервере</li>
      <li>Вес страницы — около 30–40 КБ со всеми стилями и графикой</li>
    </ul>
    <p class="small"><a class="lnk" href="{CFG['psi']}{CFG['domain'].replace('https://', '')}"
    rel="noopener" target="_blank">Прогнать этот сайт в PageSpeed Insights →</a></p>
  </div>
</section>
"""

PAGE = {
    "title": "Контакты — Новоизмайловский пр., 64к2, Московский район СПб | " + CFG["brand"],
    "description": "Контакты бюро статики: Санкт-Петербург, Новоизмайловский проспект, 64, корпус 2. "
                   "12 минут от метро «Парк Победы». Телефон, почта, Telegram, часы работы, "
                   "реквизиты и карта проезда.",
    "body": BODY, "active": "kontakty", "path": "/kontakty.html",
    "ld": {
        "@context": "https://schema.org", "@type": "ProfessionalService",
        "name": CFG["brand"], "url": CFG["domain"], "telephone": CFG["phone"],
        "email": CFG["email"], "priceRange": "₽₽",
        "address": {"@type": "PostalAddress",
                    "streetAddress": "Новоизмайловский проспект, 64, корпус 2",
                    "addressLocality": "Санкт-Петербург", "postalCode": "196128",
                    "addressCountry": "RU"},
        "geo": {"@type": "GeoCoordinates", "latitude": 59.8715, "longitude": 30.3217},
        "openingHours": "Mo-Fr 10:00-19:00",
        "hasMap": CFG["ymaps"],
    },
}
