"""Общие компоненты сайта «Бюро статики». Всё — inline-SVG и чистый HTML, без внешних ресурсов."""
from config import CFG

# ---------------------------------------------------------------- иконки
ICON = {
    "speed": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20a8 8 0 1 0-8-8"/><path d="M4 12H2"/><path d="m12 12 4-3"/><circle cx="12" cy="12" r="1"/></svg>',
    "shield": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 5 6v6c0 4 3 7 7 9 4-2 7-5 7-9V6z"/><path d="m9 12 2 2 4-4"/></svg>',
    "layers": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/></svg>',
    "phone": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/></svg>',
    "alert": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4 2.5 20h19z"/><path d="M12 10v4"/><path d="M12 17.2v.1"/></svg>',
    "money": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/></svg>',
    "clock": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.2 2"/></svg>',
    "pin": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>',
    "mail": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="m3 6 9 7 9-7"/></svg>',
    "chat": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-8 8H7l-4 3 1-5.2A8 8 0 1 1 21 12z"/></svg>',
    "doc": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h8l4 4v16H6z"/><path d="M14 2v5h4"/><path d="M9 13h6M9 17h6"/></svg>',
    "search": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/></svg>',
    "check": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="m4 12.5 5 5L20 6.5"/></svg>',
    "code": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="m8 7-5 5 5 5"/><path d="m16 7 5 5-5 5"/></svg>',
}


def icon(name, cls="icon"):
    return f'<div class="{cls}">{ICON[name]}</div>'


# ---------------------------------------------------------------- логотип
def mark(size=26, dark=False):
    """Знак бюро: монолитная плита из трёх слоёв = статическая сборка."""
    a = "#e8edf3" if dark else "#2f5d8c"
    b = "#9fb4c9" if dark else "#7f9dc0"
    c = "#dfe5ec" if dark else "#c3d2e2"
    return (
        f'<svg width="{size}" height="{size}" viewBox="0 0 32 32" fill="none" aria-hidden="true">'
        f'<rect x="1" y="1" width="30" height="30" rx="7" fill="{a if not dark else "#22303f"}"/>'
        f'<rect x="7" y="19" width="18" height="6" rx="1.6" fill="{a}"/>'
        f'<rect x="7" y="12" width="18" height="5" rx="1.6" fill="{b}"/>'
        f'<rect x="7" y="7" width="18" height="3" rx="1.5" fill="{c}"/></svg>'
    )


# ---------------------------------------------------------------- навигация
NAV = [
    ("/predlozhenie.html", "predlozhenie", "Предложение"),
    ("/uslugi.html", "uslugi", "Услуги"),
    ("/portfoliu.html", "portfoliu", "Портфолио"),
    ("/tarify.html", "tarify", "Тарифы"),
    ("/o-buro.html", "about", "О бюро"),
    ("/kontakty.html", "kontakty", "Контакты"),
]


def header(active=""):
    links = "".join(
        '<a href="%s"%s>%s</a>' % (
            url,
            ' class="is-active" aria-current="page"' if key == active else "",
            label,
        )
        for url, key, label in NAV
    )
    return f"""<header class="hdr">
  <div class="wrap hdr__in">
    <a class="brand" href="/">{mark() }<span>Бюро статики<small>Санкт-Петербург</small></span></a>
    <button class="burger" type="button" aria-label="Меню" aria-expanded="false" data-burger><span></span></button>
    <nav class="nav" data-nav>{links}</nav>
    <a class="btn btn--pri btn--sm hdr__cta" href="/auditor.html">Бесплатный аудит</a>
  </div>
</header>"""


def footer():
    nav1 = "".join(f'<li><a href="{u}">{l}</a></li>' for u, k, l in NAV)
    return f"""<footer class="ftr">
  <div class="wrap">
    <div class="ftr__grid">
      <div>
        <div class="ftr__brand">{mark(24, dark=True)} Бюро статики</div>
        <p class="small" style="color:#98a2ae;max-width:34ch">Пересобираем существующие сайты
        в статические: быстрее, современнее и без движка, который ломают.</p>
        <p class="tiny" style="color:#7f8996">ООО «Бюро статики» · ИНН {CFG['inn']} · ОГРН {CFG['ogrn']}</p>
      </div>
      <div>
        <h4>Разделы</h4>
        <ul>{nav1}
          <li><a href="/auditor.html">Бесплатный аудит</a></li>
          <li><a href="/voprosy.html">Вопросы и ответы</a></li>
        </ul>
      </div>
      <div>
        <h4>Документы</h4>
        <ul>
          <li><a href="/politika.html">Политика конфиденциальности</a></li>
          <li><a href="/soglasie.html">Согласие на обработку данных</a></li>
          <li><a href="/oferta.html">Договор-оферта</a></li>
          <li><a href="/rekvizity.html">Реквизиты</a></li>
          <li><a href="/sitemap.xml">Карта сайта</a></li>
        </ul>
      </div>
      <div>
        <h4>Контакты</h4>
        <ul>
          <li>{CFG['addr_full']}</li>
          <li><a href="tel:{CFG['phone_tel']}">{CFG['phone']}</a></li>
          <li><a href="mailto:{CFG['email']}">{CFG['email']}</a></li>
          <li><a href="{CFG['tg']}" rel="nofollow">Telegram · WhatsApp</a></li>
          <li class="tiny" style="color:#8d97a3">{CFG['hours']}</li>
        </ul>
      </div>
    </div>
    <div class="ftr__bottom">
      <span>© {CFG['year']} Бюро статики. Санкт-Петербург, Московский район.</span>
      <span class="ftr__built" data-built>Сайт собран нами: статика, 0 плагинов, 0 обновлений</span>
    </div>
  </div>
</footer>"""


# ---------------------------------------------------------------- сквозные блоки
def proof_bar(size_kb=None):
    psi = CFG["psi"] + CFG["domain"].replace("https://", "")
    w = f" · <b>{size_kb} КБ</b> эта страница" if size_kb else ""
    return f"""<div class="proof"><span class="dot" aria-hidden="true"></span>
  <span>Этот сайт — <b>статический</b>: PageSpeed <b>100</b>, 0 плагинов, 0 обновлений{w}.
  <a href="{psi}" rel="noopener" target="_blank">Проверить →</a></span></div>"""


def cta_block(title=None, text=None, btn="Получить бесплатный аудит", href="/auditor.html", extra=""):
    title = title or "Пришлём разбор вашего сайта за один рабочий день"
    text = text or ("Скорость, уязвимости, ошибки, лишние расходы на поддержку — и демо двух страниц "
                    "вашего сайта в новом виде. Бесплатно и без обязательств.")
    return f"""<section class="sec--tight"><div class="wrap"><div class="cta">
  <div><h2>{title}</h2><p>{text}</p>{extra}</div>
  <div class="row"><a class="btn btn--pri btn--lg" href="{href}">{btn}</a></div>
</div></div></section>"""


def crumbs(items):
    parts = []
    for i, (url, label) in enumerate(items):
        if i:
            parts.append('<span>/</span>')
        parts.append(f'<a href="{url}">{label}</a>' if url else f"{label}")
    return f'<div class="crumbs">{"".join(parts)}</div>'


def page_head(title, lead, crumb_list=None, extra=""):
    c = crumbs(crumb_list) if crumb_list else ""
    return f'<div class="ph"><div class="wrap">{c}<h1>{title}</h1><p class="lead">{lead}</p>{extra}</div></div>'


# ---------------------------------------------------------------- макеты телефонов «было / стало»
def _phone_was(seed, score, time, weight, plugins):
    """Макет старого сайта: тяжёлый, с попапом, битым изображением, мелким текстом."""
    h = (seed * 37) % 360
    return f"""<svg class="phone" viewBox="0 0 240 420" role="img" aria-label="Старая версия сайта: PageSpeed {score}, загрузка {time}">
<rect x="6" y="6" width="228" height="408" rx="24" fill="#2a2f36"/>
<rect x="12" y="12" width="216" height="396" rx="19" fill="#fff"/>
<rect x="12" y="12" width="216" height="26" rx="19" fill="#eceae6"/>
<circle cx="26" cy="25" r="3" fill="#c9c5bd"/><rect x="34" y="23" width="110" height="5" rx="2.5" fill="#d7d3cc"/>
<rect x="22" y="46" width="120" height="11" rx="2" fill="#8b8f96"/>
<rect x="22" y="62" width="196" height="1" fill="#ddd8d1"/>
<g font-size="7.5" fill="#9a958d" font-family="sans-serif">
<text x="22" y="74">Главная</text><text x="55" y="74">О компании</text><text x="103" y="74">Услуги</text>
<text x="140" y="74">Цены</text><text x="167" y="74">Новости</text><text x="200" y="74">Контакты</text></g>
<rect x="22" y="82" width="196" height="86" rx="3" fill="hsl({h},12%,86%)"/>
<path d="M22 82h196v86H22z" fill="none" stroke="#c6c1b8" stroke-dasharray="4 3"/>
<g stroke="#b9b3a9" stroke-width="1.4"><path d="M40 150 70 118l22 24 20-16 40 34"/><circle cx="60" cy="104" r="7" fill="#cdc7bd" stroke="none"/></g>
<rect x="22" y="176" width="150" height="9" rx="2" fill="#6f767e"/>
<g fill="#b3ada4"><rect x="22" y="192" width="196" height="5" rx="2"/><rect x="22" y="201" width="196" height="5" rx="2"/>
<rect x="22" y="210" width="176" height="5" rx="2"/><rect x="22" y="219" width="196" height="5" rx="2"/>
<rect x="22" y="228" width="140" height="5" rx="2"/></g>
<rect x="22" y="244" width="94" height="46" rx="3" fill="#e6e2db"/><rect x="124" y="244" width="94" height="46" rx="3" fill="#e6e2db"/>
<g fill="#c2bcb2"><rect x="30" y="252" width="60" height="5" rx="2"/><rect x="30" y="262" width="76" height="4" rx="2"/>
<rect x="30" y="270" width="52" height="4" rx="2"/><rect x="132" y="252" width="60" height="5" rx="2"/>
<rect x="132" y="262" width="76" height="4" rx="2"/><rect x="132" y="270" width="44" height="4" rx="2"/></g>
<g fill="#b3ada4"><rect x="22" y="300" width="196" height="5" rx="2"/><rect x="22" y="309" width="196" height="5" rx="2"/>
<rect x="22" y="318" width="160" height="5" rx="2"/><rect x="22" y="327" width="196" height="5" rx="2"/>
<rect x="22" y="336" width="120" height="5" rx="2"/><rect x="22" y="345" width="180" height="5" rx="2"/></g>
<rect x="30" y="200" width="180" height="132" rx="6" fill="#fffdf3" stroke="#d9c48a"/>
<g font-size="8" fill="#7a6a3c" font-family="sans-serif"><text x="42" y="220">🍪 Мы используем cookie,</text>
<text x="42" y="232">а ещё 4 сервиса аналитики,</text><text x="42" y="244">2 счётчика и онлайн-чат,</text>
<text x="42" y="256">которые грузятся 6 секунд…</text></g>
<rect x="42" y="272" width="72" height="20" rx="3" fill="#a8412f"/><text x="58" y="286" font-size="8.5" fill="#fff" font-family="sans-serif">Согласен</text>
<rect x="122" y="272" width="72" height="20" rx="3" fill="#e6e2db"/><text x="140" y="286" font-size="8.5" fill="#5c5f65" font-family="sans-serif">Отказ</text>
<g font-size="7" fill="#8d8880" font-family="sans-serif"><text x="42" y="308">Подписаться на рассылку</text>
<text x="42" y="322">Онлайн-консультант</text></g>
<rect x="12" y="356" width="216" height="52" fill="#f4f2ee"/>
<g font-size="7" fill="#a29d94" font-family="sans-serif"><text x="22" y="372">© 2014 Все права защищены · Joomla 1.5</text>
<text x="22" y="384">Разработка — студия «ВебМастер2009»</text><text x="22" y="396">Обновлений не было 1 847 дней</text></g>
<g transform="translate(22,344)"><rect width="88" height="17" rx="8.5" fill="#faeeeb"/>
<text x="9" y="12" font-size="9" font-weight="700" fill="#a8412f" font-family="monospace">PS {score}</text></g>
<g transform="translate(118,344)"><rect width="100" height="17" rx="8.5" fill="#f1efeb"/>
<text x="9" y="12" font-size="9" fill="#6d7783" font-family="monospace">{time} · {weight}</text></g>
<g transform="translate(22,320)"><rect width="196" height="18" rx="4" fill="#fbf4e6" stroke="#ecd9ae"/>
<text x="8" y="12.5" font-size="8" fill="#9a6b1c" font-family="sans-serif">⚠ Обнаружено {plugins} плагинов без поддержки</text></g>
</svg>"""


def _phone_now(seed, score, time, weight, accent):
    """Макет нового статического сайта: чистый, быстрый, с формой."""
    return f"""<svg class="phone" viewBox="0 0 240 420" role="img" aria-label="Новая версия сайта: PageSpeed {score}, загрузка {time}">
<rect x="6" y="6" width="228" height="408" rx="24" fill="#1b2229"/>
<rect x="12" y="12" width="216" height="396" rx="19" fill="#fff"/>
<rect x="12" y="12" width="216" height="26" rx="19" fill="#f5f4f1"/>
<circle cx="26" cy="25" r="3" fill="#cfd6dd"/><rect x="34" y="23" width="110" height="5" rx="2.5" fill="#dde2e7"/>
<rect x="22" y="48" width="196" height="30" rx="4" fill="#f7f6f3"/>
<rect x="30" y="57" width="12" height="12" rx="3" fill="{accent}"/>
<rect x="47" y="60" width="58" height="6" rx="3" fill="#2b333c"/>
<rect x="188" y="58" width="22" height="10" rx="5" fill="{accent}"/>
<rect x="22" y="88" width="196" height="96" rx="6" fill="{accent}" opacity="0.07"/>
<rect x="34" y="102" width="150" height="12" rx="3" fill="#1f2933"/>
<rect x="34" y="120" width="112" height="12" rx="3" fill="#1f2933"/>
<g fill="#7b8590"><rect x="34" y="142" width="172" height="5" rx="2.5"/><rect x="34" y="152" width="140" height="5" rx="2.5"/></g>
<rect x="34" y="164" width="76" height="16" rx="4" fill="{accent}"/>
<g font-size="7" fill="#fff" font-family="sans-serif" font-weight="600"><text x="44" y="175">Подробнее</text></g>
<g font-size="9" fill="#2b333c" font-family="sans-serif" font-weight="700">
<text x="22" y="206">Почему быстрее</text></g>
<g><rect x="22" y="214" width="60" height="52" rx="5" fill="#f7f6f3"/><rect x="90" y="214" width="60" height="52" rx="5" fill="#f7f6f3"/>
<rect x="158" y="214" width="60" height="52" rx="5" fill="#f7f6f3"/>
<g fill="{accent}"><circle cx="34" cy="228" r="6"/><circle cx="102" cy="228" r="6"/><circle cx="170" cy="228" r="6"/></g>
<g fill="#a8b0b9"><rect x="30" y="242" width="44" height="4" rx="2"/><rect x="30" y="250" width="36" height="4" rx="2"/>
<rect x="98" y="242" width="44" height="4" rx="2"/><rect x="98" y="250" width="30" height="4" rx="2"/>
<rect x="166" y="242" width="44" height="4" rx="2"/><rect x="166" y="250" width="38" height="4" rx="2"/></g></g>
<rect x="22" y="278" width="196" height="72" rx="6" fill="#fff" stroke="#dcd9d3"/>
<g font-size="8.5" fill="#2b333c" font-family="sans-serif" font-weight="700"><text x="32" y="294">Оставить заявку</text></g>
<g fill="#f3f1ed" stroke="#dcd9d3"><rect x="32" y="300" width="176" height="14" rx="3"/><rect x="32" y="318" width="176" height="14" rx="3"/></g>
<rect x="32" y="336" width="90" height="11" rx="3" fill="{accent}"/>
<g><rect x="22" y="360" width="196" height="24" rx="5" fill="#eef6f1" stroke="#cfe3d6"/>
<text x="32" y="376" font-size="8.5" fill="#245e42" font-family="sans-serif">✓ Форма работает · ответ в течение дня</text></g>
<g transform="translate(22,392)"><rect width="88" height="17" rx="8.5" fill="#eef6f1"/>
<text x="9" y="12" font-size="9" font-weight="700" fill="#2e7d53" font-family="monospace">PS {score}</text></g>
<g transform="translate(118,392)"><rect width="100" height="17" rx="8.5" fill="#f4f2ee"/>
<text x="9" y="12" font-size="9" fill="#6d7783" font-family="monospace">{time} · {weight}</text></g>
</svg>"""


def phones(seed=3, was=("34", "6,8 с", "4,2 МБ", "23"), now=("98", "0,7 с", "310 КБ", "#2f5d8c"), cap=True):
    w = _phone_was(seed, was[0], was[1], was[2], was[3])
    n = _phone_now(seed, now[0], now[1], now[2], now[3])
    c = ""
    if cap:
        c = ('<p class="tiny center" style="margin-top:12px">Мобильная версия. Слева — типовая картина '
             'сайта 2014–2018 года на CMS, справа — тот же сайт после пересборки в статику.</p>')
    return f"""<div class="ba">
  <div class="ba__col ba__col--was"><div class="ba__hd"><span>Было</span>
    <span class="ba__score">PageSpeed {was[0]}</span></div><div class="ba__body">{w}</div></div>
  <div class="ba__col ba__col--now"><div class="ba__hd"><span>Стало</span>
    <span class="ba__score">PageSpeed {now[0]}</span></div><div class="ba__body">{n}</div></div>
</div>{c}"""


# ---------------------------------------------------------------- формы
def audit_form(action="#", compact=False, domain_value=""):
    """Форма аудита. Реальную отправку подключаем на serverless-функции или в сервисе форм."""
    cls = "form" + (" form--compact" if compact else "")
    note_field = "" if compact else (
        '<div class="field"><label for="f-note">Что не так с сайтом</label>'
        '<textarea id="f-note" name="note" '
        'placeholder="Тормозит / ловили вирусы / нужен новый вид"></textarea></div>'
    )
    return f"""<form class="{cls}" action="{action}" method="post" data-form>
  <div class="form__body">
    <div class="field"><label for="f-domain">Адрес вашего сайта *</label>
      <input id="f-domain" name="domain" type="text" placeholder="primer.ru" value="{domain_value}" required
        autocomplete="url" inputmode="url"></div>
    <div class="field"><label for="f-name">Как к вам обращаться *</label>
      <input id="f-name" name="name" type="text" placeholder="Имя" required autocomplete="name"></div>
    <div class="field"><label for="f-contact">Телефон или Telegram *</label>
      <input id="f-contact" name="contact" type="text" placeholder="+7 921 000-00-00 или @username" required
        autocomplete="tel"></div>
    {note_field}
    <label class="consent"><input type="checkbox" name="agree" required>
      <span>Согласен на обработку персональных данных по <a href="/politika.html">политике конфиденциальности</a>.
      Никаких рассылок — только ответ по вашему сайту.</span></label>
    <button class="btn btn--pri btn--lg btn--blk" type="submit">Получить аудит и демо</button>
    <p class="tiny center" style="margin:12px 0 0">Ответим в течение рабочего дня. Демо присылаем за 1 день.</p>
  </div>
  <div class="form__ok"><b>Заявка принята.</b> В реальной сборке отсюда письмо уходит на {CFG['email']}
    и в Telegram. Мы уже смотрим ваш сайт — ответ придёт в течение рабочего дня.</div>
</form>"""


# ---------------------------------------------------------------- таблицы «до/после»
def metrics_table(rows=None, title=None):
    rows = rows or [
        ("PageSpeed Insights, мобильные", "34", "98"),
        ("Время полной загрузки", "6,8 с", "0,7 с"),
        ("Вес страницы", "4,2 МБ", "310 КБ"),
        ("Запросов к серверу", "112", "9"),
        ("Плагинов и обновлений", "23 / ежемесячно", "0 / никогда"),
        ("Поверхность для взлома", "CMS + БД + админка", "готовые файлы"),
        ("Поддержка в месяц", "8 000 ₽", "0–4 900 ₽"),
    ]
    body = "".join(
        f'<tr><td>{n}</td><td class="num bad">{a}</td><td class="num good">{b}</td></tr>' for n, a, b in rows
    )
    t = f'<p class="cap">{"Цифры" if not title else title}</p>'
    return f"""{t}<div class="scroll"><table class="tbl">
<thead><tr><th>Показатель</th><th class="num">Было</th><th class="num">Стало</th></tr></thead>
<tbody>{body}</tbody></table></div>"""


def schema_map():
    """Статичная карта-схема (без iframe — не ломает Core Web Vitals)."""
    return f"""<div class="map">
<svg viewBox="0 0 800 420" role="img" aria-label="Схема расположения: Новоизмайловский проспект, 64, корпус 2, Санкт-Петербург">
  <rect width="800" height="420" fill="#eef0ee"/>
  <g stroke="#dfe3dd" stroke-width="10" fill="none">
    <path d="M0 90h800M0 330h800M150 0v420M640 0v420"/></g>
  <g stroke="#e6e9e4" stroke-width="5" fill="none">
    <path d="M0 210h800M330 0v420M480 0v420M0 40h800M0 390h800"/></g>
  <path d="M330 0v420" stroke="#f0e2c4" stroke-width="16" fill="none"/>
  <g font-family="sans-serif" font-size="15" fill="#7c8798">
    <text x="345" y="30" transform="rotate(90 345 30)">Новоизмайловский пр.</text>
    <text x="16" y="82">ул. Бассейная</text><text x="16" y="322">ул. Кузнецовская</text>
    <text x="655" y="205">Варшавская</text><text x="492" y="405">пр. Юрия Гагарина</text>
  </g>
  <g fill="#dde2dc"><rect x="180" y="110" width="120" height="80" rx="3"/><rect x="500" y="110" width="110" height="80" rx="3"/>
    <rect x="180" y="240" width="120" height="70" rx="3"/><rect x="500" y="240" width="110" height="70" rx="3"/></g>
  <g transform="translate(400,180)">
    <path d="M0-34c-13 0-23 10-23 23 0 16 23 41 23 41s23-25 23-41c0-13-10-23-23-23z" fill="#2f5d8c"/>
    <circle cx="0" cy="-11" r="8.5" fill="#fff"/></g>
  <g font-family="sans-serif" font-size="16" font-weight="600" fill="#1f2933">
    <text x="436" y="176">Новоизмайловский пр., 64к2</text>
    <text x="436" y="196" font-size="13" fill="#6d7783">Бюро статики · 12 мин от м. «Парк Победы»</text></g>
  <g transform="translate(300,60)" font-family="sans-serif">
    <circle r="9" fill="#c0392b"/><text x="16" y="5" font-size="14" fill="#6d7783">м. Парк Победы</text></g>
  <g transform="translate(300,360)" font-family="sans-serif">
    <circle r="9" fill="#c0392b"/><text x="16" y="5" font-size="14" fill="#6d7783">м. Московская</text></g>
</svg>
<p class="tiny" style="position:absolute;left:14px;bottom:12px;right:14px;margin:0">
  <a href="{CFG['ymaps']}" rel="noopener" target="_blank">Открыть в Яндекс.Картах →</a>
  · живую карту подключаем ленивой загрузкой, чтобы не терять скорость страницы</p>
</div>"""


def script():
    """Минимум JS: бургер-меню, имитация отправки формы, подстановка веса страницы в подвал."""
    return """<script>
(function(){
 var b=document.querySelector('[data-burger]'),n=document.querySelector('[data-nav]');
 if(b&&n)b.addEventListener('click',function(){var o=n.classList.toggle('is-open');
   b.setAttribute('aria-expanded',o?'true':'false');});
 document.querySelectorAll('[data-form]').forEach(function(f){
   f.addEventListener('submit',function(e){e.preventDefault();f.classList.add('is-sent');
     f.scrollIntoView({block:'center'});});});
 var el=document.querySelector('[data-built]');
 if(el&&performance&&performance.getEntriesByType){
   var t=performance.getEntriesByType('navigation')[0];
   if(t&&t.transferSize)el.textContent='Эта страница: '+(t.transferSize/1024).toFixed(0)+
     ' КБ по сети · статика, 0 плагинов';
 }
})();
</script>"""
