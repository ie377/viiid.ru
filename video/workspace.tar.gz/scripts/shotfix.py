import asyncio, os
from playwright.async_api import async_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARGS = ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--single-process", "--no-zygote"]

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)
        pg = await b.new_page(viewport={"width": 1280, "height": 900})
        await pg.goto("file://" + os.path.join(ROOT, "site", "index.html"))
        await pg.wait_for_timeout(250)
        for sel, name in [(".works", "works"), (".tiles--2", "trust"), (".proof", "proof")]:
            e = await pg.query_selector(sel)
            if e:
                await e.screenshot(path=os.path.join(ROOT, "shots", "small", "fix_%s.png" % name))
                print("shot", name)
        await b.close()

asyncio.run(main())
