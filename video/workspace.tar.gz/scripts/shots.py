import asyncio, os
from playwright.async_api import async_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAGES = ["index.html","predlozhenie.html","uslugi.html","portfoliu.html","tarify.html",
         "auditor.html","o-buro.html","kontakty.html","voprosy.html",
         "portfoliu/aura-dent.html","demo-obrazets.html","404.html"]
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for vp, tag in [({"width":1280,"height":900},"desk"), ({"width":390,"height":844},"mob")]:
            pg = await b.new_page(viewport=vp, device_scale_factor=1)
            for f in PAGES:
                await pg.goto("file://"+os.path.join(ROOT,"site",f))
                await pg.wait_for_timeout(120)
                out = "shots/%s__%s.png" % (f.replace("/","_").replace(".html",""), tag)
                await pg.screenshot(path=out, full_page=True)
                print(out, os.path.getsize(out)//1024, "KB")
            await pg.close()
        await b.close()
asyncio.run(main())
