#!/usr/bin/env python3
"""Валидация собранного сайта: битые ссылки, незакрытые теги, мусор в разметке."""
import io, os, re, sys
from html.parser import HTMLParser

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "site")
VOID = {"area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr",
        "path","rect","circle","line","polyline","polygon","ellipse","use","stop"}

class V(HTMLParser):
    def __init__(s): super().__init__(convert_charrefs=True); s.stack=[]; s.err=[]
    def handle_starttag(s,t,a):
        if t not in VOID: s.stack.append((t,s.getpos()))
    def handle_startendtag(s,t,a): pass
    def handle_endtag(s,t):
        if t in VOID: return
        if not s.stack: s.err.append(f"лишний </{t}> в {s.getpos()}"); return
        if s.stack[-1][0]==t: s.stack.pop(); return
        names=[x[0] for x in s.stack]
        if t in names:
            while s.stack and s.stack[-1][0]!=t:
                bad=s.stack.pop(); s.err.append(f"не закрыт <{bad[0]}> (открыт в {bad[1]}) перед </{t}>")
            s.stack.pop()
        else: s.err.append(f"</{t}> без открывающего тега в {s.getpos()}")

files=[]
for root,_,fs in os.walk(OUT):
    for f in fs:
        if f.endswith(".html"): files.append(os.path.join(root,f))
files.sort()
problems=0
for fp in files:
    s=io.open(fp,encoding="utf-8").read()
    rel=os.path.relpath(fp,OUT)
    v=V(); v.feed(s)
    for t,pos in v.stack: v.err.append(f"не закрыт <{t}> (открыт в {pos})")
    if v.err:
        problems+=len(v.err); print(f"⚠ {rel}: разметка"); [print("   ",e) for e in v.err[:6]]
    # мусор
    for pat in [r"\{\{", r"%%", r"\{'", r'None</', r"nan ", r"\{CFG\["]:
        m=re.search(pat,s)
        if m: problems+=1; print(f"⚠ {rel}: подозрительный фрагмент {pat!r} → …{s[max(0,m.start()-60):m.start()+60]}…")
    # ссылки
    for href in re.findall(r'(?:href|src)="([^"#]+)"', s):
        if href.startswith(("http","tel:","mailto:","data:")): continue
        target = href.lstrip("/")
        if href.startswith("/") and target=="" : target="index.html"
        p=os.path.join(OUT,target)
        if not os.path.exists(p):
            problems+=1; print(f"⚠ {rel}: битая ссылка → {href}")
    # базовые SEO-проверки
    if "<title></title>" in s or 'name="description" content=""' in s:
        problems+=1; print(f"⚠ {rel}: пустой title/description")
    if s.count("<h1")>1 and "demo-obrazets" not in rel:
        problems+=1; print(f"⚠ {rel}: несколько <h1> ({s.count('<h1')})")
print("─"*60)
print(f"Проверено HTML-страниц: {len(files)} · проблем: {problems}")
sys.exit(1 if problems else 0)
