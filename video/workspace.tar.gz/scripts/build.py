#!/usr/bin/env python3
"""Сборщик сайта «Бюро статики»: src/content/*.py -> site/*.html (чистая статика).

Запуск:  python3 scripts/build.py
Результат: папка site/ — её целиком загружаем на любой статический хостинг.
"""
import importlib
import io
import json
import os
import shutil
import sys
from datetime import date

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")
OUT = os.path.join(ROOT, "site")
sys.path.insert(0, SRC)
sys.path.insert(0, os.path.join(SRC, "content"))

from config import CFG, PAGES  # noqa: E402

CSS_PATH = os.path.join(SRC, "style.css")

# Порядок сборки: модуль -> выходной файл
BUILD = [
    ("p_home", "index.html"),
    ("p_predlozhenie", "predlozhenie.html"),
    ("p_uslugi", "uslugi.html"),
    ("p_portfoliu", "portfoliu.html"),
    ("p_tarify", "tarify.html"),
    ("p_auditor", "auditor.html"),
    ("p_about", "o-buro.html"),
    ("p_kontakty", "kontakty.html"),
    ("p_voprosy", "voprosy.html"),
    ("p_cases", "portfoliu/aura-dent.html"),
    ("p_cases", "portfoliu/severny-granit.html"),
    ("p_cases", "portfoliu/avtomir-pulkovo.html"),
    ("p_demo", "demo-obrazets.html"),
    ("p_legal", "politika.html"),
    ("p_legal", "soglasie.html"),
    ("p_legal", "oferta.html"),
    ("p_legal", "rekvizity.html"),
    ("p_legal", "404.html"),
]


def template(title, description, css, ld, body, script, canonical, noindex=False,
             og_image="", body_class=""):
    ld_html = ""
    if ld:
        blocks = ld if isinstance(ld, list) else [ld]
        ld_html = "\n".join(
            '<script type="application/ld+json">' + json.dumps(b, ensure_ascii=False) + "</script>"
            for b in blocks
        )
    robots = '<meta name="robots" content="noindex,nofollow">' if noindex else ""
    og = ""
    if og_image:
        og = (f'<meta property="og:image" content="{og_image}">\n'
              '<meta property="og:image:width" content="1200">\n'
              '<meta property="og:image:height" content="630">')
    body_class_attr = f' class="{body_class}"' if body_class else ""
    return f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<meta name="description" content="{description}">
<link rel="canonical" href="{canonical}">
{robots}
<meta property="og:type" content="website">
<meta property="og:site_name" content="{CFG['brand']}">
<meta property="og:locale" content="ru_RU">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{description}">
<meta property="og:url" content="{canonical}">
{og}
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#fbfaf8">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<style>{css}</style>
{ld_html}
</head>
<body{body_class_attr}>
{body}
{script}
</body>
</html>
"""


def main():
    css = io.open(CSS_PATH, encoding="utf-8").read()
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(os.path.join(OUT, "portfoliu"), exist_ok=True)

    components = importlib.import_module("components")
    script = components.script()
    report = []

    for mod_name, out_name in BUILD:
        mod = importlib.import_module(mod_name)
        pages = mod.PAGES if hasattr(mod, "PAGES") else {out_name: mod.PAGE}
        page = pages.get(out_name) or pages["/" + out_name]
        if page.get("standalone"):
            body = page["body"]
        else:
            body = components.header(page.get("active", "")) + page["body"] + components.footer()
        html = template(
            title=page["title"],
            description=page["description"],
            css=css,
            ld=page.get("ld"),
            body=body,
            script=script,
            canonical=CFG["domain"] + page.get("path", out_name),
            noindex=page.get("noindex", False),
            og_image=page.get("og_image", ""),
            body_class=page.get("body_class", ""),
        )
        dest = os.path.join(OUT, out_name)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        io.open(dest, "w", encoding="utf-8").write(html)
        report.append((out_name, len(html.encode("utf-8"))))

    # favicon
    io.open(os.path.join(OUT, "favicon.svg"), "w", encoding="utf-8").write(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">'
        '<rect width="32" height="32" rx="7" fill="#2f5d8c"/>'
        '<rect x="7" y="19" width="18" height="6" rx="1.6" fill="#fff"/>'
        '<rect x="7" y="12" width="18" height="5" rx="1.6" fill="#c3d2e2"/>'
        '<rect x="7" y="7" width="18" height="3" rx="1.5" fill="#8fb0d1"/></svg>'
    )
    # копируем CSS отдельным файлом — удобно, если захотите перейти на кэш вместо inline
    shutil.copy(CSS_PATH, os.path.join(OUT, "style.css"))

    # sitemap.xml
    today = date.today().isoformat()
    urls = "".join(
        f"  <url><loc>{CFG['domain']}{p}</loc><lastmod>{today}</lastmod>"
        f"<changefreq>{c}</changefreq><priority>{pr}</priority></url>\n"
        for p, pr, c in PAGES
    )
    io.open(os.path.join(OUT, "sitemap.xml"), "w", encoding="utf-8").write(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + urls + "</urlset>\n"
    )
    # robots.txt
    io.open(os.path.join(OUT, "robots.txt"), "w", encoding="utf-8").write(
        f"""User-agent: *
Allow: /
Disallow: /dlja/
Disallow: /404.html

Sitemap: {CFG['domain']}/sitemap.xml
Host: {CFG['domain'].replace('https://', '')}
"""
    )
    # .htaccess: сжатие, кэш, 404, безопасность-заголовки
    io.open(os.path.join(OUT, ".htaccess"), "w", encoding="utf-8").write(
        """# Бюро статики — базовая настройка Apache
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css text/plain text/xml application/javascript image/svg+xml application/json
</IfModule>
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/html "access plus 0 seconds"
  ExpiresByType text/css "access plus 1 year"
  ExpiresByType image/svg+xml "access plus 1 year"
</IfModule>
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set X-Frame-Options "SAMEORIGIN"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
  Header set Permissions-Policy "geolocation=(), microphone=(), camera=()"
  Header set Content-Security-Policy "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self' https://mc.yandex.ru; frame-src 'none'; base-uri 'self'; form-action 'self'"
</IfModule>
ErrorDocument 404 /404.html
"""
    )

    # отчёт
    total = 0
    print(f"\nСборка {today} · {CFG['domain']}\n" + "─" * 62)
    for name, size in report:
        total += size
        print(f"  {name:<38} {size/1024:7.1f} КБ")
    print("─" * 62)
    print(f"  {'Всего страниц: ' + str(len(report)):<38} {total/1024:7.1f} КБ")
    print(f"\nГотово → {OUT}/  (загружайте содержимое папки в корень хостинга)")
    print("Проверка скорости: " + CFG["psi"] + CFG["domain"].replace("https://", ""))


if __name__ == "__main__":
    main()
